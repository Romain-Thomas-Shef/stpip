__version__ = '19.5.0'
__place__ = 'Santiago, Chile'
__credits__ = "Romain Thomas"
__license__ = "GNU GPL v3"
__maintainer__ = "Romain Thomas"
__email__ = "the.spartan.proj@gmail.com"
__status__ = "released"
__website__ = "https://github.com/astrom-tom/stpip"
