'''
Some metada
'''
__version__ = '24.11.0'
__place__ = 'Sheffield, UK'
__credits__ = "Romain Thomas"
__license__ = "GNU GPL v3"
__maintainer__ = "Romain Thomas"
__email__ = "romain.thomas@sheffield.ac.uk"
__status__ = "released"
__website__ = "https://github.com/Romain-Thomas-Shef/stpip"
